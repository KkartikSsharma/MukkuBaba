package com.username.Dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.username.bean.UserInfo;

public class UserRowMapper implements RowMapper<UserInfo> {

	public UserInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		UserInfo userInfo = new UserInfo();
		userInfo.setUserName(rs.getString(0));
		userInfo.setDateOfBirth(rs.getString(1));
		return userInfo;
	}

}
