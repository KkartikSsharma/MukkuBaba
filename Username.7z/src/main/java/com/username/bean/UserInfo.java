package com.username.bean;

public class UserInfo {
	String userName;
	String dateOfBirth;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		dateOfBirth = dateOfBirth;
	}
}
