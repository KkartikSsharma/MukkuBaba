package com.username.Service;

import com.username.Dao.DAOImpl;
import com.username.bean.UserInfo;

public class DOBService {

	DAOImpl dao = new DAOImpl();

	public void addUserInfo(UserInfo info) {
		// TODO Auto-generated method stub
		dao.addUser(info);
	}

	public UserInfo getUserInfo(String userName) {
		// TODO Auto-generated method stub
		return dao.getUser(userName);
	}
}
