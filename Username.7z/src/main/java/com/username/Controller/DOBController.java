package com.username.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.username.Service.DOBService;
import com.username.bean.UserInfo;

@RestController
public class DOBController {
	JdbcTemplate jdbcTemplate = new JdbcTemplate();

	DOBService service = new DOBService();

	@RequestMapping(value = "/addUserInfo", method = RequestMethod.POST)
	public void addUserInfo(@RequestBody UserInfo info) {
		service.addUserInfo(info);
	}

	@GetMapping("/getUserInfo/{userName}")
	public UserInfo getUserInfo(@PathVariable String username) {
		return service.getUserInfo(username);
	}
}
