package com.username.Username;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsernameApplicationTests {

	@Test
	void contextLoads() {
	}

}
